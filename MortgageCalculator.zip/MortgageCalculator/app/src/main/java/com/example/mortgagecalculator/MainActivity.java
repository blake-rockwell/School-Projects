package com.example.mortgagecalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    double purchase_price;
    double down_payment;
    double interest_rate;

    EditText purchasePrice;
    EditText downPayment;
    EditText interestRate;

    Button submitButton;

    TextView textOut10;
    TextView textOut20;
    TextView textOut30;

    SeekBar seekBar;
    TextView sbTextOut;
    TextView sbOutputAns;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        purchasePrice = (EditText) findViewById(R.id.purchasePrice);
        downPayment = (EditText) findViewById(R.id.downPayment);
        interestRate = (EditText) findViewById(R.id.interestRate);

        submitButton = (Button) findViewById(R.id.submitButton);

        submitButton.setOnClickListener(this::onClick);

        seekBar = (SeekBar)findViewById(R.id.seekBar);
        sbTextOut = (TextView)findViewById(R.id.sbTextOut);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                sbTextOut.setText("" + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void onClick(View v) {

        purchase_price = Double.parseDouble(purchasePrice.getText().toString());
        down_payment = Double.parseDouble(downPayment.getText().toString());
        interest_rate = Double.parseDouble(interestRate.getText().toString());


        textOut10 = (TextView) findViewById(R.id.outputText);
        textOut20 = (TextView) findViewById(R.id.outputText20Year);
        textOut30 = (TextView) findViewById(R.id.outputText30Year);

        sbOutputAns = (TextView) findViewById(R.id.sbOutputAns);
        int sbValue = Integer.parseInt(sbTextOut.getText().toString());


        double  r = (interest_rate*.01)/12;
        double p = (purchase_price-down_payment);

        double ans10 = (p * r) / (1 - Math.pow(1 + r, -120));
        double ans20 = (p * r) / (1 - Math.pow(1 + r, -240));
        double ans30 = (p * r) / (1 - Math.pow(1 + r, -360));
        double ansC = (p * r) / (1 - Math.pow(1 + r, -(sbValue*12)));

        textOut10.setText("10 Year Monthly Payment: " + ans10);
        textOut20.setText("20 Year Monthly Payment: " + ans20);
        textOut30.setText("30 Year Monthly Payment: " + ans30);
        sbOutputAns.setText("Custom Mortgage Payment: " + ansC);
    }
}