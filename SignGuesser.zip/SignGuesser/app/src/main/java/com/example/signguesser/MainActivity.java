package com.example.signguesser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button stopsignButton = (Button) findViewById(R.id.stopsignButton);
        Button workzoneButton = (Button) findViewById(R.id.workzoneButton);
        Button nouturnButton = (Button) findViewById(R.id.uturnButton);
        Button crosswalkButton = (Button) findViewById(R.id.crosswalkButton);


        
        stopsignButton.setOnClickListener(this::onClick);
        workzoneButton.setOnClickListener(this::onClick);
        nouturnButton.setOnClickListener(this::onClick);
        crosswalkButton.setOnClickListener(this::onClick);
    }

    private void onClick(View v) {

        //create button from clicked button,get button text string
        Button b = (Button)v;
        String buttonText = b.getText().toString();

        //find and set signview object
        ImageView signView = (ImageView) findViewById(R.id.signView);

        //reset sign image as random sign image
        int[] images = {R.drawable.crosswalk,R.drawable.workzone,R.drawable.nouturn,R.drawable.stopsign};
        Random rand = new Random();
        int randInt = rand.nextInt(images.length);

        //check answer, Toast correct or incorrect
        if (buttonText.equals("Crosswalk") && randInt == 0) {
            Toast.makeText(this.getBaseContext(), "Correct!", Toast.LENGTH_SHORT).show();
        } else if (buttonText.equals("Work Zone") && randInt == 1) {
            Toast.makeText(this.getBaseContext(), "Correct!", Toast.LENGTH_SHORT).show();
        } else if (buttonText.equals("U Turn") && randInt == 2) {
            Toast.makeText(this.getBaseContext(), "Correct!", Toast.LENGTH_SHORT).show();
        } else if (buttonText.equals("Stop Sign") && randInt == 3) {
            Toast.makeText(this.getBaseContext(), "Correct!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this.getBaseContext(), "Incorrect.", Toast.LENGTH_SHORT).show();
        }

        //change sign to random sign
        signView.setImageResource(images[randInt]);
    }
}